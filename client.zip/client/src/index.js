import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

const root = document.getElementById('root'); // Make sure you have a <div id="root"></div> in your HTML file

const reactRoot = createRoot(root);
reactRoot.render(<App />);
