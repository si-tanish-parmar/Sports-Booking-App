import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #2980b9, #3498db);
  color: #fff;
  font-family: Arial, sans-serif;
  text-align: center;
`;

const Heading = styled.h1`
  font-size: 36px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #333;
`;

const Paragraph = styled.p`
  font-size: 18px;
  margin-bottom: 20px;
  color: #fff;
`;

const ButtonContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const LinkStyled = styled(Link)`
  text-decoration: none;
  color: #fff;
  font-size: 24px;
  margin: 10px;
  padding: 10px 20px;
  border-radius: 5px;
  background-color: #3498db;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #e74c3c; /* Red for hover effect */
  }
`;

const Dashboard = () => {
  return (
    <Container>
      <Heading>Welcome to the Dashboard</Heading>
      <Paragraph>Please select your role:</Paragraph>
      <ButtonContainer>
        <LinkStyled to="/login/admin">Admin</LinkStyled>
        <LinkStyled to="/login/employee">Employee</LinkStyled>
      </ButtonContainer>
    </Container>
  );
};

export default Dashboard;
