import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import styled from 'styled-components';

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #2980b9, #3498db);
  color: #fff;
  font-family: Arial, sans-serif;
  text-align: center;
`;

const Heading = styled.h1`
  font-size: 36px;
  font-weight: bold;
  margin-bottom: 20px;
`;

const Input = styled.input`
  font-size: 18px;
  padding: 10px;
  border-radius: 5px;
  margin-bottom: 10px;
  border: none;
  background-color: rgba(255, 255, 255, 0.2);
  color: #fff;
  width: 300px;
`;

const Button = styled.button`
  font-size: 18px;
  padding: 10px 20px;
  border-radius: 5px;
  background-color: #3498db;
  border: none;
  color: #fff;
  cursor: pointer;
`;

const ErrorText = styled.p`
  color: red;
  margin-top: 10px;
`;

const EmployeeLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const history = useHistory();

  const isPasswordValid = (password) => {
    const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&*()_+\-=!])(?!.*\s).{8,20}$/;
    return passwordPattern.test(password);
  };

  const handleLogin = async () => {
    if (!isPasswordValid(password)) {
      setError(
        'Password must contain at least 8 characters, including one digit, one uppercase letter, one lowercase letter, one special character, and no spaces.'
      );
      return;
    }

    try {
      const response = await axios.get(`http://localhost:5000/api/employees/${email}`);
      const employee = response.data;

      if (employee && employee.password === password) {
        history.push('/employee');
      } else {
        setError('Invalid email or password. Please try again.');
      }
    } catch (error) {
      console.error(error);
      setError('Error fetching employee data. Please try again later.');
    }
  };

  return (
    <Container>
      <Heading>Employee Login</Heading>
      <Input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <Input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <Button onClick={handleLogin}>Log In</Button>
      {error && <ErrorText>{error}</ErrorText>}
    </Container>
  );
};

export default EmployeeLogin;
