import React, { useState, useEffect } from "react";
import axios from "axios";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #2980b9, #3498db);
  color: #fff;
  font-family: Arial, sans-serif;
  text-align: center;
`;

const ContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const ColumnsContainer = styled.div`
  display: flex;
  width: 100%;
`;

const Column = styled.div`
  flex: 1;
`;

const BookingsStyle = styled.div`
  background-color: rgba(255, 255, 255, 0.2);
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  padding: 20px;
  height: 100%;
  display: flex;
  flex-direction: column;
`;

const BookingText = styled.span`
  font-size: 16px;
  font-weight: bold;
  color: #3498db;
  padding: 5px;
`;

const BookingItem = styled.div`
  margin-bottom: 10px;
  padding: 10px;
  border-radius: 5px;
  background-color: rgba(255, 255, 255, 0.3);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  height: 100%;
`;

const StyledSelect = styled.select`
  font-size: 16px;
  padding: 10px;
  border: 2px solid #3498db;
  border-radius: 5px;
  background-color: #fff;
  color: #3498db;
`;

const EmployeeDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [venues, setVenues] = useState([]);
  const [selectedSport, setSelectedSport] = useState("");

  useEffect(() => {
    // Fetch bookings from the database using your API endpoint
    axios
      .get("http://localhost:5000/api/bookings") // Replace with your actual API endpoint
      .then((response) => setBookings(response.data))
      .catch((error) => console.error("Error fetching bookings:", error));

    // Fetch venues from the database using your API endpoint
    axios
      .get("http://localhost:5000/api/venues") // Replace with your actual API endpoint
      .then((response) => setVenues(response.data))
      .catch((error) => console.error("Error fetching venues:", error));
  }, []);

  const sportsData = [
    { id: 1, name: "Cricket" },
    { id: 2, name: "TT" },
    { id: 3, name: "Carrom" },
    { id: 4, name: "Chess" },
    { id: 5, name: "Hockey" },
    { id: 6, name: "Boxing" },
    { id: 7, name: "Lawn Tennis" },
    { id: 8, name: "Badminton" },
    { id: 9, name: "Basketball" },
  ];

  const getBookingsForSport = (selectedSportId) => {
    if (selectedSportId === "") {
      return bookings;
    } else {
      const selectedSportName = sportsData.find(
        (sport) => sport.id === parseInt(selectedSportId)
      )?.name;
      return bookings.filter((booking) => booking.sport === selectedSportName);
    }
  };

  const getVenuesForSport = (selectedSportId) => {
    if (selectedSportId === "") {
      return venues;
    } else {
      return venues.filter((venue) => {
        const venueSportIds = venue.selected_sports.map((sportId) =>
          sportId.toString()
        );
        return venueSportIds.includes(selectedSportId);
      });
    }
  };

  const formatTime = (timeString) => {
    if (!timeString) return "";
    const [hours, minutes] = timeString.split(":");
    const formattedTime = `${hours}:${minutes}`;
    return formattedTime;
  };

  return (
    <Container>
      <h1>Employee Dashboard</h1>
      <div>
        <label>Select Sport: </label>
        <StyledSelect
          value={selectedSport}
          onChange={(e) => setSelectedSport(e.target.value)}
        >
          <option value="">All Sports</option>
          {sportsData.map((sport) => (
            <option key={sport.id} value={sport.id}>
              {sport.name}
            </option>
          ))}
        </StyledSelect>
      </div>
      <ContentContainer>
        <ColumnsContainer>
          <Column>
            <BookingsStyle>
              <h2>Your Bookings</h2>
              {getBookingsForSport(selectedSport).map((booking) => (
                <BookingItem key={booking.id}>
                  <BookingText>
                    Booking Duration: {booking.duration} mins
                  </BookingText>
                  <BookingText>Sport: {booking.sport}</BookingText>
                </BookingItem>
              ))}
            </BookingsStyle>
          </Column>
          <Column>
            <BookingsStyle>
              <h2>Venues</h2>
              {getVenuesForSport(selectedSport).map((venue) => (
                <BookingItem key={venue.id}>
                  <BookingText>Venue: {venue.name}</BookingText>
                  <BookingText>
                    Venue Duration: {venue.duration} mins
                  </BookingText>
                  <BookingText>
                    Start Time: {formatTime(venue.starttime)} | End Time:{" "}
                    {formatTime(venue.endtime)}
                  </BookingText>
                  {venue.equipment && (
                    <BookingText>
                      Equipment:{" "}
                      {Object.entries(venue.equipment).map(
                        ([item, quantity]) => (
                          <span key={item}>
                            {" "}
                            | {item}: {quantity}
                          </span>
                        )
                      )}
                    </BookingText>
                  )}
                </BookingItem>
              ))}
            </BookingsStyle>
          </Column>
        </ColumnsContainer>
      </ContentContainer>
    </Container>
  );
};

export default EmployeeDashboard;
