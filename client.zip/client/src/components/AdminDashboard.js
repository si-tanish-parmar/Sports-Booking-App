import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(to bottom, #2980b9, #3498db);
  color: #fff;
  font-family: Arial, sans-serif;
  text-align: center;
`;

const DashboardContainer = styled.div`
  width: 90%;
  max-width: 800px;
  background-color: rgba(255, 255, 255, 0.1);
  padding: 20px;
  border-radius: 10px;
  margin: 20px;
  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
`;

const Heading = styled.h1`
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 20px;
`;

const SectionHeading = styled.h2`
  font-size: 28px;
  font-weight: bold;
  margin-bottom: 15px;
`;

const Button = styled.button`
  background-color: #3498db;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 14px 28px;
  font-size: 20px;
  cursor: pointer;
  margin-top: 10px;
  text-decoration: none;
  display: inline-block;
  text-align: center;
  width: 100%;
`;

const FormInput = styled.input`
  font-size: 20px;
  padding: 12px;
  width: 100%;
  border: none;
  border-radius: 5px;
  margin-bottom: 15px;
`;

const CheckboxLabel = styled.label`
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  font-size: 18px;
`;

const CheckboxInput = styled.input`
  margin-right: 10px;
`;

const VenueInfo = styled.div`
  background-color: rgba(255, 255, 255, 0.2);
  padding: 20px;
  margin: 20px 0;
  border-radius: 10px;
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.2);

  h2 {
    font-size: 24px;
    margin-bottom: 15px;
  }

  p {
    font-size: 18px;
    margin-bottom: 10px;
  }

  ul {
    list-style: none;
    padding-left: 0;
    font-size: 18px;

    li {
      margin-bottom: 10px;
    }
  }
`;

const AddVenueForm = styled.div`
  background-color: rgba(255, 255, 255, 0.2);
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.2);
  margin: 20px 0;
  display: grid;
  gap: 15px;
  grid-template-columns: repeat(
    4,
    1fr
  ); /* Four equal-width columns for the first row */

  input[type="text"],
  input[type="number"],
  input[type="time"],
  input[type="date"] {
    font-size: 18px;
    padding: 12px;
    width: 90%; /* Set all input fields to 100% width */
    border: none;
    border-radius: 5px;
    margin-bottom: 15px;
  }

  ul {
    grid-column: span 4; /* Span all four columns for the second row */
    list-style: none;
    padding-left: 0;
    font-size: 18px;
    display: grid;
    grid-template-columns: repeat(
      5,
      1fr
    ); /* Five equal-width columns for the second row */
    gap: 15px;
  }

  li {
    margin-bottom: 10px;
    display: flex;
    align-items: center;
  }

  input[type="checkbox"] {
    margin-right: 10px;
  }
`;

const AddVenueButtonContainer = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  flex-wrap: wrap;
  margin-top: 20px;
`;
const ButtonsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 2px 0; /* Add margin for spacing from the top and bottom */
  padding: 0 2px; /* Add padding for spacing from the sides */
`;

const AddVenueButton = styled(Button)`
  margin: 0 15px; /* Add margin to create space between buttons */
  min-width: 180px;
  font-size: 16px; /* Add this line to decrease text size */
`;

const AdminDashboard = () => {
  const [venues, setVenues] = useState([]);
  const [newVenue, setNewVenue] = useState("");
  const [duration, setDuration] = useState("");
  const [sports, setSports] = useState([]);
  const [selectedSports, setSelectedSports] = useState([]);
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [date, setDate] = useState("");
  const [equipmentData, setEquipmentData] = useState({});
  const [equipmentKey, setEquipmentKey] = useState("");
  const [equipmentValue, setEquipmentValue] = useState("");
  const [sportInventory, setSportInventory] = useState({});
  const [sportData, setSportData] = useState({});

  useEffect(() => {
    // Fetch venues
    axios
      .get("http://localhost:5000/api/venues")
      .then((response) => setVenues(response.data))
      .catch((error) => console.error("Error fetching venues:", error));

    // Fetch sports
    axios
      .get("http://localhost:5000/api/sports")
      .then((response) => {
        const sportsData = {};
        response.data.forEach((sport) => {
          sportsData[sport.id] = sport;
        });
        setSports(response.data);
      })
      .catch((error) => console.error("Error fetching sports:", error));
  }, []);

  const handleVenueSubmit = () => {
    // Validate that startTime and endTime are not empty strings
    if (!startTime || !endTime) {
      console.error("Start Time and End Time are required.");
      return;
    }

    const selectedSportsJSON = JSON.stringify(selectedSports);

    const newVenueData = {
      name: newVenue,
      duration: parseInt(duration),
      selected_sports: selectedSportsJSON,
      startTime, // Ensure startTime is a valid time value
      endTime, // Ensure endTime is a valid time value
      date,
      equipment: equipmentData,
    };

    axios
      .post("http://localhost:5000/api/venues", newVenueData)
      .then((response) => {
        setVenues([...venues, response.data]);
        setNewVenue("");
        setDuration("");
        setSelectedSports([]);
        setStartTime("");
        setEndTime("");
        setDate("");
        setEquipmentData({});
      })
      .catch((error) => console.error("Error adding venue:", error));
  };

  const addEquipment = () => {
    if (equipmentKey && equipmentValue) {
      setEquipmentData({
        ...equipmentData,
        [equipmentKey]: equipmentValue,
      });
      setEquipmentKey("");
      setEquipmentValue("");
    }
  };

  const removeEquipment = (key) => {
    const updatedEquipmentData = { ...equipmentData };
    delete updatedEquipmentData[key];
    setEquipmentData(updatedEquipmentData);
  };

  const toggleSportSelection = (sportId) => {
    if (selectedSports.includes(sportId)) {
      setSelectedSports(selectedSports.filter((id) => id !== sportId));
    } else {
      setSelectedSports([...selectedSports, sportId]);
    }
  };
  const formatTime = (timeString) => {
    if (!timeString) return ""; // Handle empty time strings
    const [hours, minutes] = timeString.split(":");
    const formattedTime = `${hours}:${minutes}`;
    return formattedTime;
  };

  return (
    <Container>
      <Heading>Admin Dashboard</Heading>
      <DashboardContainer>
        {/* Venues */}
        <SectionHeading>Venues</SectionHeading>
        {venues.map((venue) => (
          <VenueInfo key={venue.id}>
            <h2>
              {venue.name} (Duration: {venue.duration} mins)
            </h2>
            <p>Date: {new Date(venue.date).toLocaleDateString()}</p>
            <p>
              Start Time: {formatTime(venue.starttime)} | End Time:{" "}
              {formatTime(venue.endtime)}
            </p>
            <h3>Selected Sports:</h3>
            <ul>
              {venue.selected_sports && venue.selected_sports.length > 0 ? (
                venue.selected_sports.map((sportId) => (
                  <li key={sportId}>
                    {sports.find((sport) => sport.id === sportId) ? (
                      <span>
                        {sports.find((sport) => sport.id === sportId).name}
                      </span>
                    ) : (
                      "Sport data not found"
                    )}
                  </li>
                ))
              ) : (
                <li>No sports associated with this venue.</li>
              )}
            </ul>
            <h3>Equipment:</h3>
            <ul>
              {venue.equipment &&
                Object.entries(venue.equipment).map(([key, value]) => (
                  <li key={key}>
                    {key}: {value}
                  </li>
                ))}
            </ul>
          </VenueInfo>
        ))}
      </DashboardContainer>
      <DashboardContainer>
        {/* Add New Venue */}
        <SectionHeading>Add New Venue</SectionHeading>
        <AddVenueForm>
          <FormInput
            type="text"
            placeholder="Venue Name"
            value={newVenue}
            onChange={(e) => setNewVenue(e.target.value)}
          />
          <FormInput
            type="number"
            placeholder="Duration (mins)"
            value={duration}
            onChange={(e) => setDuration(e.target.value)}
          />
          <FormInput
            type="time"
            placeholder="Start Time"
            value={startTime}
            onChange={(e) => setStartTime(e.target.value)}
          />
          <FormInput
            type="time"
            placeholder="End Time"
            value={endTime}
            onChange={(e) => setEndTime(e.target.value)}
          />
          <FormInput
            type="date"
            placeholder="Date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />

          <FormInput
            type="text"
            placeholder="Equipment Name"
            value={equipmentKey}
            onChange={(e) => setEquipmentKey(e.target.value)}
          />
          <FormInput
            type="text"
            placeholder="Quantity"
            value={equipmentValue}
            onChange={(e) => setEquipmentValue(e.target.value)}
          />
          <Button onClick={addEquipment} style={{ fontSize: "16px" }}>
            Add Equipment
          </Button>
          <ul>
            {sports.map((sport) => (
              <li key={sport.id}>
                <CheckboxLabel>
                  <CheckboxInput
                    type="checkbox"
                    value={sport.id}
                    checked={selectedSports.includes(sport.id)}
                    onChange={() => toggleSportSelection(sport.id)}
                  />
                  {sport.name}
                </CheckboxLabel>
              </li>
            ))}
          </ul>
        </AddVenueForm>
      </DashboardContainer>
      <DashboardContainer>
        <ButtonsContainer>
          <AddVenueButton onClick={handleVenueSubmit} style={{ flex: "1" }}>
            Add Venue
          </AddVenueButton>
          <Link to="/booking" style={{ textDecoration: "none" }}>
            <Button style={{ flex: "1", fontSize: "16px" }}>
              Go to Booking Page
            </Button>
          </Link>
        </ButtonsContainer>
      </DashboardContainer>
    </Container>
  );
};

export default AdminDashboard;
