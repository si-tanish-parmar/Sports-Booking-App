import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const Booking = () => {
  const [selectedSport, setSelectedSport] = useState('');
  const [selectedVenue, setSelectedVenue] = useState('');
  const [duration, setDuration] = useState('');
  const [bookingStatus, setBookingStatus] = useState('');
  const [venues, setVenues] = useState([]);
  const [sports, setSports] = useState([]);
  const [availableEquipment, setAvailableEquipment] = useState([]); // Add state for available equipment

  const history = useHistory();

  useEffect(() => {
    // Fetch available venues from your backend API
    axios.get('http://localhost:5000/api/venues')
      .then((response) => setVenues(response.data))
      .catch((error) => console.error('Error fetching venues:', error));

    // Fetch available sports from your backend API
    axios.get('http://localhost:5000/api/sports')
      .then((response) => setSports(response.data))
      .catch((error) => console.error('Error fetching sports:', error));
  }, []);

  // Fetch available equipment based on the selected sport
  useEffect(() => {
    if (selectedSport) {
      axios.get(`http://localhost:5000/api/equipment/${selectedSport}`)
        .then((response) => setAvailableEquipment(response.data))
        .catch((error) => console.error('Error fetching equipment:', error));
    }
  }, [selectedSport]);

  const handleBookingSubmit = () => {
    axios
      .post('http://localhost:5000/api/bookings', {
        sport: selectedSport,
        venueId: selectedVenue,
        equipment: 'All available equipment will be allotted', // Update the equipment message
        duration: parseInt(duration),
      })
      .then((response) => {
        setBookingStatus('Booking Successful!');
        setSelectedSport('');
        setSelectedVenue('');
        setDuration('');

        setTimeout(() => {
          history.push('/booking');
        }, 2000);
      })
      .catch((error) => {
        console.error('Error making booking:', error);
        setBookingStatus('Booking Failed. Please try again.');
      });
  };

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    background: 'linear-gradient(to bottom, #2980b9, #3498db)',
    color: '#fff',
    fontFamily: 'Arial, sans-serif',
    textAlign: 'center',
  };

  const dashboardStyle = {
    width: '400px',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    padding: '20px',
    borderRadius: '5px',
    marginTop: '20px',
  };

  const headingStyle = {
    fontSize: '24px',
    fontWeight: 'bold',
    marginBottom: '20px',
  };

  const addButtonStyle = {
    backgroundColor: '#3498db',
    color: '#fff',
    border: 'none',
    borderRadius: '5px',
    padding: '12px 24px',
    fontSize: '18px',
    cursor: 'pointer',
    marginTop: '10px',
    textDecoration: 'none',
    display: 'inline-block',
    textAlign: 'center',
    width: '100%',
  };

  const selectStyle = {
    fontSize: '16px',
    padding: '10px',
    width: '100%',
    border: 'none',
    borderRadius: '5px',
    marginBottom: '10px',
  };

  const inputStyle = {
    fontSize: '16px',
    padding: '10px',
    width: '95%',
    border: 'none',
    borderRadius: '5px',
    marginBottom: '10px',
  };

  return (
    <div style={containerStyle}>
      <h1>Make a Booking</h1>
      <div style={dashboardStyle}>
        <h2 style={headingStyle}>Booking Details</h2>
        <select
          value={selectedSport}
          onChange={(e) => setSelectedSport(e.target.value)}
          style={selectStyle}
        >
          <option value="" disabled>
            Select Sport
          </option>
          {sports.map((sport) => (
            <option key={sport.id} value={sport.name}>
              {sport.name}
            </option>
          ))}
        </select>
        <select
          value={selectedVenue}
          onChange={(e) => setSelectedVenue(e.target.value)}
          style={selectStyle}
        >
          <option value="" disabled>
            Select Venue
          </option>
          {venues.map((venue) => (
            <option key={venue.id} value={venue.id}>
              {venue.name} (Duration: {venue.duration} mins)
            </option>
          ))}
        </select>
        <p>Equipment: All available equipment will be allotted</p> {/* Display equipment message */}
        <input
          type="number"
          placeholder="Duration (mins)"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          style={inputStyle}
        />
        <button onClick={handleBookingSubmit} style={addButtonStyle}>
          Make Booking
        </button>
        {bookingStatus && <p>{bookingStatus}</p>}
      </div>
    </div>
  );
};

export default Booking;
