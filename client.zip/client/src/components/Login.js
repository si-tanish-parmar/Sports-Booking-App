import React, { useState } from 'react';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginStatus, setLoginStatus] = useState('');

  const handleLoginSubmit = () => {
    // Send a POST request to your backend API for user authentication
    // Example API call:
    // fetch('/api/login', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({ email, password }),
    // })
    //   .then((response) => response.json())
    //   .then((data) => {
    //     // Handle the login response, set user authentication state, and redirect
    //     if (data.success) {
    //       // Redirect to the user's dashboard or homepage
    //       window.location.href = '/dashboard';
    //     } else {
    //       setLoginStatus('Login failed. Please check your credentials.');
    //     }
    //   })
    //   .catch((error) => {
    //     console.error('Error during login:', error);
    //     setLoginStatus('Login failed. Please try again later.');
    //   });

    // Mock response for demonstration
    if (email === 'user@example.com' && password === 'password') {
      setLoginStatus('Login successful!');
      // Redirect to the user's dashboard or homepage
      // For demonstration, we'll use a timeout to simulate the redirection
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1000);
    } else {
      setLoginStatus('Login failed. Please check your credentials.');
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLoginSubmit}>Log In</button>
      {loginStatus && <p>{loginStatus}</p>}
    </div>
  );
};

export default Login;
