import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import AdminDashboard from './components/AdminDashboard';
import EmployeeDashboard from './components/EmployeeDashboard';
import Booking from './components/Booking';
import EmployeeLogin from './components/EmployeeLogin';
import AdminLogin from './components/AdminLogin';


const App = () => {
  return (
    <Router>
      <div>
        {/* Header or navigation component can be placed here */}
        <Switch>
          <Route path="/" exact component={Dashboard} />
          <Route path="/login/admin" component={AdminLogin} />
          <Route path="/login/employee" component={EmployeeLogin} />
          <Route path="/admin" component={AdminDashboard} />
          <Route path="/employee" component={EmployeeDashboard} />
          <Route path="/booking" component={Booking} />
          {/* Add more routes as needed */}
        </Switch>
      </div>
    </Router>
  );
};

export default App;
